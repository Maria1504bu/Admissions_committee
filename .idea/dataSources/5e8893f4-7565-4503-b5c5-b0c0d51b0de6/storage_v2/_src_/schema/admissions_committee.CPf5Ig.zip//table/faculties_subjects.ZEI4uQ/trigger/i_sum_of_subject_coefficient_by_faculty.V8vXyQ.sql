create definer = Maria1504@`%` trigger i_sum_of_subject_coefficient_by_faculty
    after insert
    on faculties_subjects
    for each row
BEGIN
    DECLARE coef_sum INT;
    DECLARE error_message VARCHAR(255);
    SELECT SUM(subject_coefficient)
    FROM faculties_subjects
    WHERE faculty_id = NEW.faculty_id
    INTO coef_sum;

    SET error_message = CONCAT('Sum of subject_coefficients must can`t be more than 100  but is ', coef_sum);
    IF coef_sum > 100 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = error_message;
    end if;
END;

