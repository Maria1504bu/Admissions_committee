create definer = Maria1504@`%` trigger i_counting_rating_score
    before insert
    on applications
    for each row
BEGIN
DECLARE cur_subj_id, sum_score INT DEFAULT 0;
DECLARE cursor_list_is_done BOOLEAN DEFAULT false;
DECLARE cursor_List CURSOR FOR
    SELECT subject_id FROM faculties_subjects WHERE faculties_subjects.faculty_id = NEW.faculty_id;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET cursor_list_is_done = TRUE;

OPEN cursor_List;

loop_List:
    LOOP
        FETCH cursor_List INTO cur_subj_id;
IF cursor_list_is_done THEN
            LEAVE loop_List;
end if;
        -- multiply by 2, because max rating score must be 200 and subject_coefficient is in percents
insert INTO log value (now(), cur_subj_id);
        SET sum_score = sum_score + (2 * (SELECT grade FROM grades WHERE subject_id = cur_subj_id AND candidate_id = NEW.login_id) /
                         (SELECT maxGrade FROM subjects WHERE subjects.id = cur_subj_id) *
                         (SELECT subject_coefficient FROM faculties_subjects WHERE subject_id = cur_subj_id AND faculty_id=NEW.faculty_id));
INSERT INTO log VALUE (now(), (2 * (SELECT grade FROM grades WHERE subject_id = cur_subj_id AND candidate_id = NEW.login_id) /
                               (SELECT maxGrade FROM subjects WHERE subjects.id = cur_subj_id) *
                               (SELECT subject_coefficient FROM faculties_subjects WHERE subject_id = cur_subj_id AND faculty_id=NEW.faculty_id)));
INSERT INTO log VALUE (now(), sum_score);

END LOOP;
CLOSE cursor_List;
SET NEW.rating_score = sum_score;
END;

